package com.dicoding.submissionintermediatedicoding.data.auth

data class UserRegisterResponse(
    val error: Boolean,
    val message: String
)
