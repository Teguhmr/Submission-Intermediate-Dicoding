package com.dicoding.submissionintermediatedicoding.utils


sealed class ApiState{
    object Loading : ApiState()
    object Failure : ApiState()
    object Success : ApiState()
    object Empty : ApiState()
}
