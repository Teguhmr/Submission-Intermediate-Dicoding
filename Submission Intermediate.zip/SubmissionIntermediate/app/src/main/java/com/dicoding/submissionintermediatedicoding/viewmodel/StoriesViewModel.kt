package com.dicoding.submissionintermediatedicoding.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.submissionintermediatedicoding.data.remote.RetrofitConfig
import com.dicoding.submissionintermediatedicoding.data.story.Story
import com.dicoding.submissionintermediatedicoding.data.story.StoryListResponse
import com.dicoding.submissionintermediatedicoding.utils.ApiState
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class StoriesViewModel: ViewModel() {
    private val _listStoryData = MutableLiveData<ArrayList<Story>>()
    val listStoryData : LiveData<ArrayList<Story>> = _listStoryData

    private val _message = MutableLiveData<String>()

    val loading = MutableLiveData<ApiState>()

    fun getAllStoriesData(auth: String){
        loading.postValue(ApiState.Loading)
        RetrofitConfig.getApiService().getAllStory("Bearer $auth")
            .enqueue(object : Callback<StoryListResponse> {
                override fun onResponse(
                    call: Call<StoryListResponse>,
                    response: Response<StoryListResponse>
                ) {
                    if (response.isSuccessful){
                        if (response.body()!!.listStory.isNotEmpty()){
                            _listStoryData.postValue(response.body()?.listStory)
                            loading.postValue(ApiState.Success)
                        } else {
                            loading.postValue(ApiState.Empty)
                        }
                    }else{
                        loading.postValue(ApiState.Failure)
                        _message.postValue(response.message())
                    }

                }

                override fun onFailure(call: Call<StoryListResponse>, t: Throwable) {
                    loading.postValue(ApiState.Failure)
                    _message.value = t.message
                }

            })
    }
}