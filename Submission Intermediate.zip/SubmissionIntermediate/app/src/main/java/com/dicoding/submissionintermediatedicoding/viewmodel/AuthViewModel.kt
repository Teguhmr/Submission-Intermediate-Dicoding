package com.dicoding.submissionintermediatedicoding.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.submissionintermediatedicoding.data.auth.UserLoginResponse
import com.dicoding.submissionintermediatedicoding.data.auth.UserLoginResult
import com.dicoding.submissionintermediatedicoding.data.auth.UserRegisterResponse
import com.dicoding.submissionintermediatedicoding.data.remote.RetrofitConfig
import com.dicoding.submissionintermediatedicoding.utils.ApiState
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AuthViewModel : ViewModel(){
    private val _usrLogin = MutableLiveData<UserLoginResult>()
    val usrLogin: LiveData<UserLoginResult> = _usrLogin

    private val _message = MutableLiveData<String>()

    val loading = MutableLiveData<ApiState>()
    val loadingRegister = MutableLiveData<ApiState>()

    fun doLogin(email:String, password:String){
        loading.postValue(ApiState.Loading)
        RetrofitConfig.getApiService().userLogin(email, password)
            .enqueue(object : Callback<UserLoginResponse> {
                override fun onResponse(
                    call: Call<UserLoginResponse>,
                    response: Response<UserLoginResponse>
                ) {
                    if (response.isSuccessful){
                        loading.postValue(ApiState.Success)
                        _usrLogin.value = response.body()?.loginResult
                    } else {
                        loading.postValue(ApiState.Failure)
                        _message.value = response.message()
                    }
                }

                override fun onFailure(call: Call<UserLoginResponse>, t: Throwable) {
                    _message.value = t.message
                    loading.postValue(ApiState.Failure)
                }

            })
    }

    fun doRegister(name: String, email: String, password: String){
        loadingRegister.postValue(ApiState.Loading)
        RetrofitConfig.getApiService().userRegister(name,email,password)
            .enqueue(object : Callback<UserRegisterResponse>{
                override fun onResponse(
                    call: Call<UserRegisterResponse>,
                    response: Response<UserRegisterResponse>
                ) {
                    if (response.isSuccessful){
                        loadingRegister.postValue(ApiState.Success)
                    } else {
                        loadingRegister.postValue(ApiState.Failure)
                        _message.value = response.message()
                    }
                }

                override fun onFailure(call: Call<UserRegisterResponse>, t: Throwable) {
                    _message.value = t.message
                    loadingRegister.postValue(ApiState.Failure)
                }

            })
    }
}