package com.dicoding.submissionintermediatedicoding.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.submissionintermediatedicoding.data.remote.RetrofitConfig
import com.dicoding.submissionintermediatedicoding.data.story.AddStoryResponse
import com.dicoding.submissionintermediatedicoding.utils.ApiState
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UploadImageViewModel: ViewModel() {
    val loading = MutableLiveData<ApiState>()

    fun uploadStory(token: String, image: MultipartBody.Part, description: RequestBody){
        loading.postValue(ApiState.Loading)
        RetrofitConfig.getApiService().uploadStory(token, image, description).
        enqueue(object : Callback<AddStoryResponse> {
            override fun onResponse(call: Call<AddStoryResponse>, response: Response<AddStoryResponse>) {
                if (response.isSuccessful) {
                    loading.postValue(ApiState.Success)
                }
            }

            override fun onFailure(call: Call<AddStoryResponse>, t: Throwable) {
                loading.postValue(ApiState.Failure)

            }

        })
    }

}